"""Telegram Mini App initData 验证工具"""
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl
from typing import Optional
from .config import settings


def validate_init_data(init_data: str, bot_token: Optional[str] = None) -> dict:
    """
    验证 Telegram Mini App 的 initData 签名
    参考: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
    
    返回解析后的用户数据字典，验证失败则抛出 ValueError
    """
    token = bot_token or settings.TG_BOT_TOKEN
    if not token:
        raise ValueError("TG_BOT_TOKEN 未配置")
    
    # 使用 parse_qsl 解析并 URL 解码 query string
    parsed_pairs = parse_qsl(init_data, keep_blank_values=True)
    
    received_hash = None
    data_pairs = []
    user_value = None
    auth_date_value = None
    
    for key, value in parsed_pairs:
        if key == "hash":
            received_hash = value
        else:
            data_pairs.append((key, value))
            if key == "user":
                user_value = value
            elif key == "auth_date":
                auth_date_value = value
    
    if not received_hash:
        raise ValueError("缺少 hash 字段")
    
    # 按 key 字母序排店，用解码后的值构建 data-check-string
    data_pairs.sort(key=lambda x: x[0])
    data_check_string = "\n".join(f"{k}={v}" for k, v in data_pairs)
    
    # 计算 HMAC-SHA256
    secret_key = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    
    if not hmac.compare_digest(computed_hash, received_hash):
        raise ValueError("initData 签名验证失败")
    
    # 验证 auth_date 是否过期 (允许 24 小时)
    if auth_date_value:
        auth_date = int(auth_date_value)
        if time.time() - auth_date > 86400:
            raise ValueError("initData 已过期")
    
    # 解析 user 字段
    if not user_value:
        raise ValueError("缺少 user 字段")
    
    user_data = json.loads(user_value)
    return user_data
