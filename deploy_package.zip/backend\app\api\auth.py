from typing import Optional
from datetime import datetime
from pydantic import BaseModel
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import Session, select, func
from app.core.database import get_session
from app.core.security import verify_password, get_password_hash, create_access_token
from app.core.dependencies import get_current_user, require_admin, require_super_admin
from app.core.rate_limit import login_protector
from app.core.telegram import validate_init_data
from app.models import User, UserRole, ApprovalStatus
from app.api.schemas import (
    UserCreate, UserLogin, UserResponse, TokenResponse, MessageResponse, 
    UserUpdate, PasswordChange,
    UserApprovalRequest, PendingUserResponse, TelegramAuthRequest
)

router = APIRouter()


def _user_response(user: User) -> UserResponse:
    """构建 UserResponse"""
    # 资料完整性：必须有姓名、电话、地址（且不是 TG 自动生成的默认名）
    profile_completed = bool(
        user.full_name
        and not user.full_name.startswith("TG_")
        and user.phone
        and user.address
    )
    return UserResponse(
        id=user.id,
        username=user.username,
        full_name=user.full_name,
        role=user.role,
        phone=user.phone,
        address=user.address,
        credit_limit=user.credit_limit,
        billing_cycle_days=user.billing_cycle_days,
        allow_credit=user.allow_credit,
        location_url=user.location_url,
        store_photo=user.store_photo,
        telegram_id=user.telegram_id,
        notify_enabled=user.notify_enabled,
        must_change_password=user.must_change_password,
        is_active=user.is_active,
        approval_status=user.approval_status,
        rejected_reason=user.rejected_reason,
        profile_completed=profile_completed,
    )


def _generate_account_number(session: Session, role: UserRole) -> str:
    """根据角色自动生成6位账号"""
    if role == UserRole.ADMIN:
        start, end = 100001, 200000
    else:
        start, end = 200001, 299999

    # 查找该范围内已有的最大账号
    # 修复: 使用 CAST 转为整数做比较，避免字符串排序导致的错误
    from sqlalchemy import Integer, cast
    existing = session.exec(
        select(func.max(cast(User.username, Integer)))
        .where(cast(User.username, Integer) >= start)
        .where(cast(User.username, Integer) <= end)
    ).first()

    if existing:
        next_num = existing + 1
    else:
        next_num = start

    if next_num > end:
        raise HTTPException(status_code=400, detail="账号已用尽")

    return str(next_num)


# ============= Telegram Mini App 免登录 =============

@router.post("/telegram-auth", response_model=TokenResponse)
def telegram_auth(
    data: TelegramAuthRequest,
    session: Session = Depends(get_session),
):
    """Telegram Mini App 免登录接口
    
    验证 Telegram initData 签名，自动创建或登录用户
    """
    try:
        tg_user = validate_init_data(data.init_data)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Telegram 验证失败: {e}"
        )
    
    tg_id = tg_user["id"]
    
    # 查找已绑定的用户
    user = session.exec(
        select(User).where(User.telegram_id == tg_id)
    ).first()
    
    if not user:
        # 自动创建新用户 - 待审核状态，需填写资料后管理员审核
        first_name = tg_user.get("first_name", "")
        last_name = tg_user.get("last_name", "")
        full_name = f"{first_name} {last_name}".strip() or f"TG_{tg_id}"
        
        username = f"tg_{tg_id}"
        
        user = User(
            username=username,
            hashed_password=get_password_hash(f"tg_auto_{tg_id}"),
            full_name=full_name,
            role=UserRole.MERCHANT,
            telegram_id=tg_id,
            approval_status=ApprovalStatus.PENDING,  # 新用户待审核
            must_change_password=False,
        )
        session.add(user)
        session.commit()
        session.refresh(user)
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="账号已被禁用"
        )
    
    # 不再阻止 pending/rejected 用户登录 —— 前端根据状态引导用户填写资料
    access_token = create_access_token(data={"sub": str(user.id)})
    
    return TokenResponse(
        access_token=access_token,
        user=_user_response(user)
    )


# ============= 管理员创建用户接口 =============

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(
    user_data: UserCreate,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """注册新用户 - 管理员创建"""
    # 权限检查：只有超级管理员(100001)能创建管理员
    if user_data.role == UserRole.ADMIN and current_user.username != "100001":
        raise HTTPException(status_code=403, detail="仅超级管理员可创建管理员账号")

    # 商户必须有手机号(手机号即账号)，管理员自动生成账号
    if user_data.role == UserRole.MERCHANT:
        if not user_data.phone:
            raise HTTPException(status_code=400, detail="商户必须填写手机号")
        # 检查手机号是否已被使用
        existing = session.exec(
            select(User).where(User.username == user_data.phone)
        ).first()
        if existing:
            raise HTTPException(status_code=400, detail="该手机号已被注册")
        username = user_data.phone
    else:
        # 管理员使用自动生成的账号
        username = _generate_account_number(session, user_data.role)

    # 创建新用户，默认密码 123456
    user = User(
        username=username,
        hashed_password=get_password_hash("123456"),
        full_name=user_data.full_name,
        role=user_data.role,
        phone=user_data.phone,
        address=user_data.address,
        location_url=user_data.location_url,
        credit_limit=user_data.credit_limit,
        billing_cycle_days=user_data.billing_cycle_days,
        allow_credit=user_data.allow_credit,
        approval_status=ApprovalStatus.APPROVED,  # 管理员创建的默认已通过
        must_change_password=True,
    )

    session.add(user)
    session.commit()
    session.refresh(user)

    return _user_response(user)


@router.post("/login", response_model=TokenResponse)
def login(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    session: Session = Depends(get_session),
):
    """用户登录 - 仅管理员可用账号密码登录，商户必须通过 Telegram 登录"""
    client_ip = request.client.host if request.client else "unknown"

    # --- 防暴力破解: 登录前检查频率 ---
    login_protector.check_login(client_ip, form_data.username)

    # 查找用户
    user = session.exec(
        select(User).where(User.username == form_data.username)
    ).first()

    if not user or not verify_password(form_data.password, user.hashed_password):
        login_protector.record_failure(client_ip, form_data.username)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # 仅管理员可通过账号密码登录
    if user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="商户请通过 Telegram Mini App 登录"
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="账号已被禁用"
        )
    
    access_token = create_access_token(data={"sub": str(user.id)})
    
    return TokenResponse(
        access_token=access_token,
        user=_user_response(user)
    )


@router.get("/me", response_model=UserResponse)
def get_current_user_info(
    current_user: User = Depends(get_current_user),
):
    """获取当前用户信息"""
    return _user_response(current_user)


@router.get("/users", response_model=list[UserResponse])
def list_users(
    role: UserRole | None = None,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """获取用户列表 - 仅管理员"""
    query = select(User)
    if role:
        query = query.where(User.role == role)
    
    users = session.exec(query).all()
    return [_user_response(user) for user in users]


@router.patch("/users/{user_id}", response_model=UserResponse)
def update_user(
    user_id: int,
    user_data: UserUpdate,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """更新用户信息 - 管理员"""
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    # 保护超级管理员(100001)不能被禁用
    if user.username == "100001" and user_data.is_active is not None and not user_data.is_active:
        raise HTTPException(status_code=400, detail="不能禁用超级管理员")
    
    # 仅超级管理员可修改用户角色
    if user_data.role is not None and current_user.username != "100001":
        raise HTTPException(status_code=403, detail="仅超级管理员可修改用户角色")
    
    # 普通管理员不能修改其他管理员
    if user.role == UserRole.ADMIN and current_user.username != "100001":
        raise HTTPException(status_code=403, detail="仅超级管理员可管理管理员账号")
    
    for key, value in user_data.model_dump(exclude_unset=True).items():
        setattr(user, key, value)
    
    session.add(user)
    session.commit()
    session.refresh(user)
    
    return _user_response(user)


@router.post("/users/{user_id}/reset-password", response_model=MessageResponse)
def reset_password(
    user_id: int,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """重置用户密码为123456 - 仅超级管理员(100001)"""
    if current_user.username != "100001":
        raise HTTPException(status_code=403, detail="仅超级管理员可重置密码")
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    user.hashed_password = get_password_hash("123456")
    user.must_change_password = True
    session.add(user)
    session.commit()
    return MessageResponse(message="密码已重置为123456")


@router.delete("/users/{user_id}", response_model=MessageResponse)
def delete_user(
    user_id: int,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """删除用户 - 仅超级管理员(100001)"""
    if current_user.username != "100001":
        raise HTTPException(status_code=403, detail="仅超级管理员可删除用户")
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="不能删除自己")
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    # 检查是否有关联订单
    from app.models import Order
    order_count = session.exec(
        select(func.count(Order.id)).where(Order.merchant_id == user_id)
    ).one()
    if order_count > 0:
        raise HTTPException(status_code=400, detail=f"该用户有 {order_count} 条关联订单，无法删除，建议停用")
    session.delete(user)
    session.commit()
    return MessageResponse(message="用户已删除")


@router.post("/change-password", response_model=MessageResponse)
def change_password(
    data: PasswordChange,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """修改密码 - 当前用户"""
    if not verify_password(data.old_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="原密码错误")
    
    current_user.hashed_password = get_password_hash(data.new_password)
    current_user.must_change_password = False
    session.add(current_user)
    session.commit()
    
    return MessageResponse(message="密码修改成功")


class ProfileUpdate(BaseModel):
    """用户自行更新个人信息"""
    full_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    location_url: Optional[str] = None
    store_photo: Optional[str] = None
    notify_enabled: Optional[bool] = None


@router.patch("/me", response_model=UserResponse)
def update_profile(
    data: ProfileUpdate,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """更新个人信息 - 当前用户"""
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(current_user, key, value)
    
    session.add(current_user)
    session.commit()
    session.refresh(current_user)
    
    return _user_response(current_user)


class AdminTelegramBind(BaseModel):
    """管理员绑定Telegram ID"""
    telegram_id: Optional[int] = None


@router.patch("/me/telegram", response_model=UserResponse)
def update_admin_telegram(
    data: AdminTelegramBind,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """绑定/解绑管理员 Telegram ID - 仅管理员"""
    current_user.telegram_id = data.telegram_id
    session.add(current_user)
    session.commit()
    session.refresh(current_user)
    return _user_response(current_user)


@router.post("/submit-review", response_model=MessageResponse)
def submit_for_review(
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """用户提交/重新提交资料审核"""
    if current_user.role == UserRole.ADMIN:
        raise HTTPException(status_code=400, detail="管理员无需审核")
    
    # 验证资料完整性
    if not current_user.full_name or current_user.full_name.startswith("TG_"):
        raise HTTPException(status_code=400, detail="请先填写店铺名称")
    if not current_user.phone:
        raise HTTPException(status_code=400, detail="请先填写电话")
    if not current_user.address:
        raise HTTPException(status_code=400, detail="请先填写地址")
    
    if current_user.approval_status == ApprovalStatus.APPROVED:
        return MessageResponse(message="您的账号已通过审核")
    
    # PENDING 或 REJECTED 均可（重新）提交
    current_user.approval_status = ApprovalStatus.PENDING
    current_user.rejected_reason = None
    session.add(current_user)
    session.commit()
    
    return MessageResponse(message="资料已提交，请等待管理员审核")


# ============= 用户审核接口 (管理员) =============

@router.get("/pending-users", response_model=list[PendingUserResponse])
def list_pending_users(
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """获取待审核用户列表 - 仅管理员"""
    users = session.exec(
        select(User)
        .where(User.approval_status == ApprovalStatus.PENDING)
        .order_by(User.created_at.desc())
    ).all()
    
    return [
        PendingUserResponse(
            id=u.id,
            username=u.username,
            full_name=u.full_name,
            phone=u.phone or "",
            address=u.address,
            approval_status=u.approval_status,
            rejected_reason=u.rejected_reason,
            created_at=u.created_at.strftime("%Y-%m-%d %H:%M"),
        )
        for u in users
    ]


@router.get("/all-registrations", response_model=list[PendingUserResponse])
def list_all_registrations(
    status: Optional[ApprovalStatus] = None,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """获取所有注册用户列表(可按审核状态筛选) - 仅管理员"""
    query = select(User).where(User.role == UserRole.MERCHANT)
    
    if status:
        query = query.where(User.approval_status == status)
    
    users = session.exec(query.order_by(User.created_at.desc())).all()
    
    return [
        PendingUserResponse(
            id=u.id,
            username=u.username,
            full_name=u.full_name,
            phone=u.phone or "",
            address=u.address,
            approval_status=u.approval_status,
            rejected_reason=u.rejected_reason,
            created_at=u.created_at.strftime("%Y-%m-%d %H:%M"),
        )
        for u in users
    ]


@router.post("/users/{user_id}/approve", response_model=MessageResponse)
def approve_user(
    user_id: int,
    data: UserApprovalRequest,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """审核用户 - 仅管理员"""
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    if user.role == UserRole.ADMIN:
        raise HTTPException(status_code=400, detail="不能审核管理员账号")
    
    if data.approved:
        user.approval_status = ApprovalStatus.APPROVED
        user.approved_at = datetime.now(timezone(timedelta(hours=7)))
        user.rejected_reason = None
        message = f"用户 {user.full_name}({user.username}) 审核已通过"
    else:
        if not data.rejected_reason:
            raise HTTPException(status_code=400, detail="拒绝时必须填写原因")
        user.approval_status = ApprovalStatus.REJECTED
        user.rejected_reason = data.rejected_reason
        message = f"用户 {user.full_name}({user.username}) 已被拒绝"
    
    session.add(user)
    session.commit()
    
    return MessageResponse(message=message)


@router.get("/pending-count")
def get_pending_count(
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """获取待审核用户数量 - 仅管理员"""
    count = session.exec(
        select(func.count(User.id))
        .where(User.approval_status == ApprovalStatus.PENDING)
    ).one()
    
    return {"count": count}
