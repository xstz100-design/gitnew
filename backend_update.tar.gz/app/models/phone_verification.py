from datetime import datetime, timedelta
from typing import Optional

from sqlmodel import SQLModel, Field

from .base import CAMBODIA_TZ


def _now_cambodia():
    return datetime.now(CAMBODIA_TZ)


class PhoneVerification(SQLModel, table=True):
    """Telegram 手机号验证码记录"""
    __tablename__ = "phone_verifications"

    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(index=True)
    phone: str = Field(max_length=20, index=True)
    code: str = Field(max_length=6)
    expires_at: datetime = Field(default_factory=lambda: _now_cambodia() + timedelta(minutes=10), index=True)
    used_at: Optional[datetime] = Field(default=None, index=True)
    created_at: datetime = Field(default_factory=_now_cambodia, index=True)