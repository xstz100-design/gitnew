"""Telegram Bot 通知服务

使用全局 TG_BOT_TOKEN 发送所有通知。
管理员通知: 发送给所有设置了 telegram_id 的管理员
用户通知: 发送给用户的 telegram_id
"""
import httpx
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def _escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _get_global_bot_token() -> str:
    """获取全局 Bot Token"""
    from app.core.config import settings
    return settings.TG_BOT_TOKEN


async def send_telegram_message(bot_token: str, chat_id: str, message: str) -> bool:
    """发送 Telegram 消息"""
    if not bot_token or not chat_id:
        return False
    
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML",
    }
    
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(url, json=payload)
            if resp.status_code == 200:
                logger.info(f"Telegram 消息发送成功: chat_id={chat_id}")
                return True
            else:
                logger.warning(f"Telegram 消息发送失败: {resp.status_code} {resp.text}")
                return False
    except Exception as e:
        logger.error(f"Telegram 消息发送异常: {e}")
        return False


def send_telegram_sync(bot_token: str, chat_id: str, message: str) -> bool:
    """同步方式发送 Telegram 消息 (用于非异步上下文)"""
    if not bot_token or not chat_id:
        return False
    
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML",
    }
    
    try:
        with httpx.Client(timeout=10) as client:
            resp = client.post(url, json=payload)
            if resp.status_code == 200:
                logger.info(f"Telegram 消息发送成功: chat_id={chat_id}")
                return True
            else:
                logger.warning(f"Telegram 消息发送失败: {resp.status_code} {resp.text}")
                return False
    except Exception as e:
        logger.error(f"Telegram 消息发送异常: {e}")
        return False


def _send_to_user(user, message: str, ignore_notify_disabled: bool = False) -> bool:
    """通过全局 Bot 向用户发送消息。

    普通业务通知遵守 notify_enabled。
    安全类消息（如手机号验证码）应绕过通知开关，避免用户关掉营销通知后无法完成实名或资料校验。
    """
    if not user or not user.telegram_id:
        return False
    if not ignore_notify_disabled and hasattr(user, 'notify_enabled') and not user.notify_enabled:
        return False
    bot_token = _get_global_bot_token()
    return send_telegram_sync(bot_token, str(user.telegram_id), message)


def _send_to_admins(session, message: str):
    """通过全局 Bot 向所有管理员发送消息"""
    from app.models import User, UserRole
    from sqlmodel import select
    
    bot_token = _get_global_bot_token()
    if not bot_token:
        return
    
    admins = session.exec(
        select(User).where(
            User.role == UserRole.ADMIN,
            User.telegram_id.isnot(None),  # type: ignore
        )
    ).all()
    
    for admin in admins:
        if admin.telegram_id:
            send_telegram_sync(bot_token, str(admin.telegram_id), message)


# ============= 消息格式化 =============

def format_new_order_message(order_no: str, merchant_name: str, total_usd: float, items: list) -> str:
    """格式化新订单通知消息"""
    item_lines = []
    for item in items:
        safe_product_name = _escape_html(str(item['product_name']))
        item_lines.append(f"- {safe_product_name} x{item['quantity']} = ${item['subtotal_usd']:.2f}")
    
    items_text = "\n".join(item_lines)
    safe_order_no = _escape_html(order_no)
    safe_merchant_name = _escape_html(merchant_name)
    
    return (
        f"<b>New Order</b>\n"
        f"Order No: <code>{safe_order_no}</code>\n"
        f"Merchant: {safe_merchant_name}\n"
        f"Total: <b>${total_usd:.2f}</b>\n"
        f"Items:\n{items_text}\n"
        f"Please process promptly."
    )


def format_low_stock_message(product_name: str, current_stock: int, warning_level: int) -> str:
    """格式化库存预警消息"""
    safe_product_name = _escape_html(product_name)
    return (
        f"<b>Low Stock Alert</b>\n"
        f"Product: {safe_product_name}\n"
        f"Current Stock: <b>{current_stock}</b>\n"
        f"Warning Level: {warning_level}\n"
        f"Please restock soon."
    )


# ============= 管理员通知 =============

def notify_admins_new_order(session, order_no: str, merchant_name: str, total_usd: float, items: list):
    """通知管理员: 新订单"""
    message = format_new_order_message(order_no, merchant_name, total_usd, items)
    _send_to_admins(session, message)


def notify_admins_low_stock(session, product_name: str, current_stock: int, warning_level: int):
    """通知管理员: 库存预警"""
    message = format_low_stock_message(product_name, current_stock, warning_level)
    _send_to_admins(session, message)


# ============= 用户通知 =============

def notify_user_order_created(user, order_no: str, total_usd: float):
    """通知用户: 下单成功"""
    safe_order_no = _escape_html(order_no)
    message = (
        f"<b>Order Placed</b>\n"
        f"Order No: <code>{safe_order_no}</code>\n"
        f"Total: <b>${total_usd:.2f}</b>\n"
        f"We will arrange delivery for you soon."
    )
    _send_to_user(user, message)


def notify_user_order_completed(user, order_no: str, total_usd: float):
    """通知用户: 订单已完成(签收)"""
    safe_order_no = _escape_html(order_no)
    message = (
        f"<b>Order Delivered</b>\n"
        f"Order No: <code>{safe_order_no}</code>\n"
        f"Amount: <b>${total_usd:.2f}</b>\n"
        f"Thank you for your purchase."
    )
    _send_to_user(user, message)


def notify_user_billing_due(session, merchant):
    """通知用户: 账期到期"""
    if not merchant or not merchant.telegram_id or not merchant.billing_cycle_days:
        return

    safe_name = _escape_html(merchant.full_name)
    
    message = (
        f"<b>Payment Due Reminder</b>\n"
        f"Merchant: {safe_name}\n"
        f"Billing Cycle: Every {merchant.billing_cycle_days} days\n"
        f"Credit Limit: <b>${merchant.credit_limit:.2f}</b>\n"
        f"Please settle your account promptly."
    )
    _send_to_user(merchant, message)


def format_phone_verification_message(phone: str, code: str) -> str:
    """格式化手机号验证码消息"""
    safe_phone = _escape_html(phone)
    safe_code = _escape_html(code)
    return (
        f"<b>手机号验证</b>\n"
        f"手机号: <code>{safe_phone}</code>\n"
        f"验证码: <b>{safe_code}</b>\n"
        f"有效期: 10 分钟\n"
        f"如果这不是你本人操作，请忽略此消息。"
    )


def send_phone_verification_code(user, phone: str, code: str) -> bool:
    """向当前 Telegram 用户发送手机号验证码"""
    return _send_to_user(
        user,
        format_phone_verification_message(phone, code),
        ignore_notify_disabled=True,
    )
