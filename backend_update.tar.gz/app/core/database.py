from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy import event, inspect, text
from .config import settings

SUPER_ADMIN_BOOTSTRAP_USERNAME = "100001"

# ---------- 引擎配置（适配 2G 内存 + SQLite）----------
#
# SQLite 注意事项:
# - check_same_thread=False: 允许多线程复用同一连接（FastAPI 多线程需要）
# - pool_size=5:   最多保持 5 个常驻连接，节省内存
# - max_overflow=0: 不允许额外溢出连接，防止 OOM
# - pool_recycle=3600: 1小时回收空闲连接
# - pool_pre_ping=True: 使用前 ping 一次，防止用到已断开的连接
#
_connect_args = {}
if settings.DATABASE_URL.startswith("sqlite"):
    _connect_args = {"check_same_thread": False}

engine = create_engine(
    settings.DATABASE_URL,
    echo=False,                    # 生产环境关闭 SQL 日志
    pool_pre_ping=True,
    pool_size=5,
    max_overflow=0,
    pool_recycle=3600,
    connect_args=_connect_args,
)

# SQLite 性能优化: 每个连接启用 WAL 模式 + busy_timeout
if settings.DATABASE_URL.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=5000")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA cache_size=-8000")  # 8MB cache
        cursor.close()


def ensure_user_schema_updates():
    """补齐用户表中需要的兼容字段，并回填超级管理员标记。"""
    with engine.begin() as conn:
        inspector = inspect(conn)
        if "users" not in inspector.get_table_names():
            return

        columns = {column["name"] for column in inspector.get_columns("users")}
        dialect = conn.dialect.name

        if "is_super_admin" not in columns:
            if dialect == "sqlite":
                conn.exec_driver_sql(
                    "ALTER TABLE users ADD COLUMN is_super_admin INTEGER NOT NULL DEFAULT 0"
                )
            elif dialect == "postgresql":
                conn.exec_driver_sql(
                    "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_super_admin BOOLEAN NOT NULL DEFAULT FALSE"
                )
            else:
                conn.execute(
                    text("ALTER TABLE users ADD COLUMN is_super_admin BOOLEAN NOT NULL DEFAULT FALSE")
                )

        if dialect == "sqlite":
            conn.execute(
                text(
                    """
                    UPDATE users
                    SET is_super_admin = 1
                    WHERE role = 'admin'
                      AND username = :username
                      AND COALESCE(is_super_admin, 0) = 0
                    """
                ),
                {"username": SUPER_ADMIN_BOOTSTRAP_USERNAME},
            )


def _add_boolean_column_if_missing(conn, table_name: str, column_name: str):
    inspector = inspect(conn)
    columns = {column["name"] for column in inspector.get_columns(table_name)}
    if column_name in columns:
        return

    dialect = conn.dialect.name
    if dialect == "sqlite":
        conn.exec_driver_sql(
            f"ALTER TABLE {table_name} ADD COLUMN {column_name} INTEGER NOT NULL DEFAULT 0"
        )
    elif dialect == "postgresql":
        conn.exec_driver_sql(
            f"ALTER TABLE {table_name} ADD COLUMN IF NOT EXISTS {column_name} BOOLEAN NOT NULL DEFAULT FALSE"
        )
    else:
        conn.execute(
            text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} BOOLEAN NOT NULL DEFAULT FALSE")
        )


def _add_varchar_column_if_missing(conn, table_name: str, column_name: str, length: int):
    inspector = inspect(conn)
    columns = {column["name"] for column in inspector.get_columns(table_name)}
    if column_name in columns:
        return

    dialect = conn.dialect.name
    if dialect == "postgresql":
        conn.exec_driver_sql(
            f"ALTER TABLE {table_name} ADD COLUMN IF NOT EXISTS {column_name} VARCHAR({length})"
        )
    else:
        conn.execute(
            text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} VARCHAR({length})")
        )


def ensure_product_schema_updates():
    with engine.begin() as conn:
        inspector = inspect(conn)
        if "products" not in inspector.get_table_names():
            return

        _add_boolean_column_if_missing(conn, "products", "is_deleted")
        conn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_products_is_deleted ON products (is_deleted)"
        )
        conn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_products_category_is_deleted ON products (category, is_deleted)"
        )


def ensure_order_schema_updates():
    with engine.begin() as conn:
        inspector = inspect(conn)
        table_names = set(inspector.get_table_names())
        if "orders" not in table_names:
            return

        _add_boolean_column_if_missing(conn, "orders", "is_deleted")
        _add_varchar_column_if_missing(conn, "orders", "client_request_id", 64)

        conn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_orders_is_deleted ON orders (is_deleted)"
        )
        conn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_orders_merchant_created_at ON orders (merchant_id, created_at)"
        )
        conn.exec_driver_sql(
            "CREATE UNIQUE INDEX IF NOT EXISTS ux_orders_merchant_client_request_id ON orders (merchant_id, client_request_id)"
        )

        if "order_items" in table_names:
            conn.exec_driver_sql(
                "CREATE INDEX IF NOT EXISTS ix_order_items_order_id ON order_items (order_id)"
            )
            conn.exec_driver_sql(
                "CREATE INDEX IF NOT EXISTS ix_order_items_product_id ON order_items (product_id)"
            )
        else:
            conn.execute(
                text(
                    """
                    UPDATE users
                    SET is_super_admin = TRUE
                    WHERE role = 'admin'
                      AND username = :username
                      AND COALESCE(is_super_admin, FALSE) = FALSE
                    """
                ),
                {"username": SUPER_ADMIN_BOOTSTRAP_USERNAME},
            )


def create_db_and_tables():
    """创建所有表"""
    SQLModel.metadata.create_all(engine)
    ensure_user_schema_updates()
    ensure_product_schema_updates()
    ensure_order_schema_updates()


def get_session():
    """获取数据库会话 - 用于依赖注入"""
    with Session(engine) as session:
        yield session
