"""迁移脚本: 添加 notify_enabled 字段"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "cambodia_wholesale.db")

def migrate():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # 检查字段是否已存在
    cursor.execute("PRAGMA table_info(users)")
    columns = [row[1] for row in cursor.fetchall()]
    
    if "notify_enabled" not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN notify_enabled INTEGER DEFAULT 1")
        print("✅ Added notify_enabled column (default=1)")
    else:
        print("ℹ️ notify_enabled column already exists")
    
    conn.commit()
    conn.close()
    print("Migration complete.")

if __name__ == "__main__":
    migrate()
