"""数据库迁移: 月结 → 账期(天)

变更内容:
1. users 表: billing_day → billing_cycle_days
2. users 表: allow_monthly_billing → allow_credit
3. monthly_bills 表: 新增 period_start, period_end 字段
"""
import sqlite3
import sys
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "cambodia_wholesale.db")


def migrate():
    if not os.path.exists(DB_PATH):
        print(f"数据库文件不存在: {DB_PATH}")
        sys.exit(1)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    try:
        # 检查当前列
        cursor.execute("PRAGMA table_info(users)")
        user_columns = {row[1] for row in cursor.fetchall()}

        # 1. billing_day → billing_cycle_days
        if "billing_day" in user_columns and "billing_cycle_days" not in user_columns:
            cursor.execute("ALTER TABLE users RENAME COLUMN billing_day TO billing_cycle_days")
            print("✅ users: billing_day → billing_cycle_days")
        elif "billing_cycle_days" in user_columns:
            print("⏭️  users: billing_cycle_days 已存在，跳过")
        else:
            print("⚠️  users: billing_day 列不存在")

        # 2. allow_monthly_billing → allow_credit
        if "allow_monthly_billing" in user_columns and "allow_credit" not in user_columns:
            cursor.execute("ALTER TABLE users RENAME COLUMN allow_monthly_billing TO allow_credit")
            print("✅ users: allow_monthly_billing → allow_credit")
        elif "allow_credit" in user_columns:
            print("⏭️  users: allow_credit 已存在，跳过")
        else:
            print("⚠️  users: allow_monthly_billing 列不存在")

        # 3. monthly_bills 表: 新增 period_start, period_end
        cursor.execute("PRAGMA table_info(monthly_bills)")
        bill_columns = {row[1] for row in cursor.fetchall()}

        if "period_start" not in bill_columns:
            cursor.execute("ALTER TABLE monthly_bills ADD COLUMN period_start TEXT")
            print("✅ monthly_bills: 新增 period_start")
        else:
            print("⏭️  monthly_bills: period_start 已存在，跳过")

        if "period_end" not in bill_columns:
            cursor.execute("ALTER TABLE monthly_bills ADD COLUMN period_end TEXT")
            print("✅ monthly_bills: 新增 period_end")
        else:
            print("⏭️  monthly_bills: period_end 已存在，跳过")

        conn.commit()
        print("\n🎉 迁移完成!")

    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}")
        sys.exit(1)
    finally:
        conn.close()


if __name__ == "__main__":
    migrate()
