import logging
import sys
from pathlib import Path

from loguru import logger


class InterceptHandler(logging.Handler):
    def emit(self, record):
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        logger.opt(depth=6, exception=record.exc_info).log(level, record.getMessage())


def setup_logging():
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)

    logger.remove()
    logger.add(sys.stdout, level="INFO", enqueue=True)
    logger.add(
        logs_dir / "error.log",
        level="ERROR",
        rotation="7 days",
        retention="14 days",
        enqueue=True,
        encoding="utf-8",
    )

    intercept_handler = InterceptHandler()
    logging.basicConfig(handlers=[intercept_handler], level=logging.INFO, force=True)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        logging.getLogger(name).handlers = [intercept_handler]
        logging.getLogger(name).propagate = False