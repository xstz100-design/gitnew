from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select, func
from app.core.database import get_session
from app.core.dependencies import get_current_user, require_admin
from app.models import MonthlyBill, BillStatus, Order, PaymentStatus, DeliveryStatus, User, UserRole
from app.api.schemas import MonthlyBillResponse, MonthlyBillUpdate, MessageResponse

router = APIRouter()

CAMBODIA_TZ = timezone(timedelta(hours=7))


def _bill_response(bill, merchant_name: str = None) -> MonthlyBillResponse:
    return MonthlyBillResponse(
        id=bill.id,
        merchant_id=bill.merchant_id,
        merchant_name=merchant_name or "",
        year=bill.year,
        month=bill.month,
        period_start=bill.period_start.isoformat() if bill.period_start else None,
        period_end=bill.period_end.isoformat() if bill.period_end else None,
        total_amount=bill.total_amount,
        paid_amount=bill.paid_amount,
        status=bill.status,
        created_at=bill.created_at.isoformat() if bill.created_at else "",
    )


@router.get("", response_model=list[MonthlyBillResponse])
def list_monthly_bills(
    merchant_id: int | None = None,
    year: int | None = None,
    month: int | None = None,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """获取月结账单列表"""
    query = select(MonthlyBill)

    if current_user.role == UserRole.MERCHANT:
        query = query.where(MonthlyBill.merchant_id == current_user.id)
    elif merchant_id:
        query = query.where(MonthlyBill.merchant_id == merchant_id)

    if year:
        query = query.where(MonthlyBill.year == year)
    if month:
        query = query.where(MonthlyBill.month == month)

    bills = session.exec(query.order_by(MonthlyBill.year.desc(), MonthlyBill.month.desc())).all()

    # 获取商户名称
    merchant_ids = list(set(b.merchant_id for b in bills))
    merchants = {}
    if merchant_ids:
        users = session.exec(select(User).where(User.id.in_(merchant_ids))).all()
        merchants = {u.id: u.full_name for u in users}

    return [_bill_response(b, merchants.get(b.merchant_id, "")) for b in bills]


@router.post("/generate", response_model=MessageResponse)
def generate_monthly_bills(
    year: int = None,
    month: int = None,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """生成账期账单 - 管理员
    
    按每个商户的 billing_cycle_days 生成账单。
    若传入 year/month 兼容旧逻辑；否则自动按账期天数计算。
    """
    now = datetime.now(CAMBODIA_TZ)
    
    # 获取所有有账期设置的商户
    merchants = session.exec(
        select(User).where(
            User.role == UserRole.MERCHANT,
            User.billing_cycle_days.isnot(None),
        )
    ).all()

    count = 0
    for merchant in merchants:
        cycle_days = merchant.billing_cycle_days or 30

        # 查找该商户最近一期账单的截止日
        last_bill = session.exec(
            select(MonthlyBill).where(
                MonthlyBill.merchant_id == merchant.id,
            ).order_by(MonthlyBill.period_end.desc())
        ).first()

        if last_bill and last_bill.period_end:
            period_start = last_bill.period_end
        else:
            # 首次生成: 从商户创建时间开始
            period_start = merchant.created_at or now - timedelta(days=cycle_days)

        period_end = period_start + timedelta(days=cycle_days)

        # 如果账期尚未到期，跳过
        if period_end > now:
            continue

        # 检查是否已存在相同时段的账单
        existing = session.exec(
            select(MonthlyBill).where(
                MonthlyBill.merchant_id == merchant.id,
                MonthlyBill.period_start == period_start,
                MonthlyBill.period_end == period_end,
            )
        ).first()
        if existing:
            continue

        # 查询该时段内该商户的赊账订单总额
        total = session.exec(
            select(func.coalesce(func.sum(Order.total_usd), 0)).where(
                Order.merchant_id == merchant.id,
                Order.created_at >= period_start,
                Order.created_at <= period_end,
                Order.delivery_status != DeliveryStatus.CANCELLED,
            )
        ).one()

        bill = MonthlyBill(
            merchant_id=merchant.id,
            year=period_end.year,
            month=period_end.month,
            period_start=period_start,
            period_end=period_end,
            total_amount=float(total),
            paid_amount=0.0,
            status=BillStatus.UNPAID if float(total) > 0 else BillStatus.PAID,
        )
        session.add(bill)
        count += 1

    session.commit()

    # TG 通知商户账期到期
    try:
        from app.services.telegram import notify_user_billing_due
        for merchant in merchants:
            notify_user_billing_due(session, merchant)
    except Exception:
        pass

    return MessageResponse(message=f"已生成 {count} 条账期账单")


@router.patch("/{bill_id}", response_model=MonthlyBillResponse)
def update_monthly_bill(
    bill_id: int,
    data: MonthlyBillUpdate,
    session: Session = Depends(get_session),
    current_user: User = Depends(require_admin),
):
    """更新月结账单 - 管理员"""
    bill = session.get(MonthlyBill, bill_id)
    if not bill:
        raise HTTPException(status_code=404, detail="账单不存在")

    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(bill, key, value)

    # 自动计算状态
    if bill.paid_amount >= bill.total_amount:
        bill.status = BillStatus.PAID
    elif bill.paid_amount > 0:
        bill.status = BillStatus.PARTIAL
    else:
        bill.status = BillStatus.UNPAID

    bill.updated_at = datetime.now(CAMBODIA_TZ)
    session.add(bill)
    session.commit()
    session.refresh(bill)

    merchant = session.get(User, bill.merchant_id)
    return _bill_response(bill, merchant.full_name if merchant else "")
